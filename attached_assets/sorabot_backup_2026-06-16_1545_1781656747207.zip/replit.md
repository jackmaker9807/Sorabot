# SoraBot v2

SoraBot is a Discord AI bot dashboard — manage your bot, configure auto-response rules, set AI providers, and monitor activity logs from a single web UI.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/discord-bot run dev` — run the dashboard frontend (port 20320)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 + WebSockets (ws)
- Bot: Discord.js v14
- DB: SQLite (default, via better-sqlite3 + Drizzle ORM) or PostgreSQL (set via `db-config.json`)
- AI: OpenAI, Gemini (configurable per-provider from dashboard)
- Frontend: React + Vite + Tailwind + shadcn/ui + wouter
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/` — Express API + Discord.js bot backend
- `artifacts/discord-bot/` — React/Vite dashboard frontend
- `artifacts/api-server/src/lib/db.ts` — SQLite/PG dual-mode DB with auto-migration
- `artifacts/api-server/src/lib/discord-bot.ts` — Discord.js bot lifecycle
- `artifacts/api-server/src/lib/ai-responder.ts` — Multi-provider AI response engine
- `artifacts/api-server/data/db-config.json` — Switch between sqlite and postgresql
- `lib/api-spec/openapi.yaml` — OpenAPI spec (source of truth for API contract)
- `lib/api-client-react/` — Generated React Query hooks
- `lib/api-zod/` — Generated Zod schemas for server validation

## Architecture decisions

- SQLite is the default DB (no external provisioning needed). Switch to PostgreSQL by editing `data/db-config.json`.
- Bot auto-starts on server boot if a Discord token is present in `bot_settings` table or `DISCORD_BOT_TOKEN` env var.
- Auth is token-based (JWT-style stored in localStorage). `setAuthTokenGetter` in `@workspace/api-client-react` injects it into all API calls.
- WebSocket at `/ws` (served by API server) pushes real-time updates (bot status, new logs, stats) to the dashboard.
- AI provider priority is configurable — multiple providers can be added and the bot tries them in priority order.

## Product

- **Overview**: Bot status toggle, today's replies, active rules count, connected servers, recent activity feed.
- **Rules Engine**: Create keyword-based auto-response rules with exact/contains/startsWith matching and case sensitivity.
- **Logs**: Full message log of bot interactions with filter support.
- **Credentials**: Set Discord bot token and AI provider API keys.
- **Settings**: Bot personality prompt, AI toggle, respond-to-all vs mention-only, GIF/sticker settings.
- **Account**: Change admin username and password.

## Default credentials

- Username: `admin`
- Password: `admin`

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Do NOT run `pnpm dev` at workspace root — apps are started via workflows with `PORT`/`BASE_PATH` env vars.
- After changing `lib/*` packages, run `pnpm run typecheck:libs` before checking leaf packages.
- The API server uses SQLite by default — no `DATABASE_URL` is required unless switching to PostgreSQL.
- `/ws` must be listed in the API server's `artifact.toml` paths for WebSocket proxying to work.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
