# SoraBot

SoraBot adalah Discord bot dengan AI yang dilengkapi dashboard web untuk konfigurasi dan monitoring.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — jalankan API server (port 8080)
- `pnpm --filter @workspace/discord-bot run dev` — jalankan dashboard frontend (port 20320)
- `pnpm run typecheck` — full typecheck semua packages
- `pnpm run build` — typecheck + build semua packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks dan Zod schemas dari OpenAPI spec

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: SQLite (better-sqlite3) — file di `artifacts/api-server/data/sora.db`
- ORM: Drizzle ORM
- Frontend: React + Vite + Tailwind CSS
- Discord: discord.js v14
- AI: OpenAI / Gemini / custom provider
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/src/` — Express API + Discord bot logic
- `artifacts/api-server/src/lib/discord-bot.ts` — Discord bot client
- `artifacts/api-server/src/lib/ai-responder.ts` — AI response logic
- `artifacts/api-server/data/sora.db` — SQLite database (source of truth)
- `artifacts/api-server/data/db-config.json` — konfigurasi provider DB (sqlite/postgres)
- `artifacts/discord-bot/src/` — React dashboard frontend
- `lib/api-spec/openapi.yaml` — OpenAPI spec (source of truth untuk API contract)

## Architecture decisions

- Database disimpan sebagai SQLite lokal by default (bisa switch ke PostgreSQL via `db-config.json`)
- Discord token dan admin password disimpan di database (bukan env var) agar bisa diubah via dashboard
- Bot Discord auto-start saat server start jika token sudah dikonfigurasi
- AI provider mendukung multi-provider dengan priority fallback
- WebSocket (`/ws`) digunakan untuk realtime update dari bot ke dashboard

## Product

- Dashboard web untuk konfigurasi Discord bot
- Manajemen rules (keyword → response)
- Konfigurasi AI provider (Gemini, OpenAI, dll)
- Log percakapan bot
- User profiling berdasarkan riwayat percakapan
- Toggle bot on/off dari dashboard

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Discord token dikonfigurasi via dashboard (Settings page), bukan env var
- Database SQLite berada di `artifacts/api-server/data/sora.db`
- Setelah mengubah OpenAPI spec, selalu jalankan codegen sebelum menggunakan type yang baru

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
